package tutorialB;

import bugwars.UnitController;

public class Spider extends MyUnit {

    Spider(UnitController unitController){
        super(unitController);
    }

    public void play() {
        //No spiders yet! :)
    }
}
