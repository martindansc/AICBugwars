package tutorialB;

import bugwars.UnitController;

public class Bee extends MyUnit {

    Bee(UnitController unitController){
        super(unitController);
    }

    public void play() {
        //nothing yet!
    }
}
